import threading
import time
import os
import ctypes
from tkinter import ttk
import customtkinter as ctk
import updater
import injector
from PIL import Image, ImageTk
import selfupdate  # Import selfupdate.py

class LynnnMenuLaunchpad(ctk.CTk):
    def __init__(self):  
        super().__init__()
        self.title("LynnnMenu Launchpad")
        self.geometry("400x350")
        self.iconbitmap("./images/cherry-logo.ico")
        self.resizable(False, False)
        self.disable_resize_and_maximize()

        # Memeriksa kemas kini secara automatik apabila aplikasi dilancarkan
        threading.Thread(target=self.check_for_updates).start()

        # UI Utama
        self.title_label = ctk.CTkLabel(
            self, text="Welcome babe ;3", font=("Helvetica", 24, "bold")
        )
        self.title_label.pack(pady=20)

        self.update_button = ctk.CTkButton(
            self, text="Update", command=self.start_check_for_updates
        )
        self.update_button.pack(pady=10)

        self.inject_button = ctk.CTkButton(
            self, text="Inject", command=self.start_injection
        )
        self.inject_button.pack(pady=10)

        # Button Discord dengan Ikon
        self.discord_icon = Image.open("discord_icon.png")
        self.discord_icon = self.discord_icon.resize((30, 30), Image.Resampling.LANCZOS)
        self.discord_icon = ImageTk.PhotoImage(self.discord_icon)

        self.discord_button = ctk.CTkButton(
            self, text="Join Discord", image=self.discord_icon, compound="left", command=self.open_discord
        )
        self.discord_button.pack(pady=10)

        # Made by Zarif label
        self.made_by_label = ctk.CTkLabel(
            self, text="2024 LynnnMenu - All Rights Reserved - Developer: Lynnn", font=("Helvetica", 12)
        )
        self.made_by_label.pack(side="bottom", pady=10)

        self.progress_window = None  # Untuk simpan reference animasi loading

    def disable_resize_and_maximize(self):
        """This function disables resizing and maximizing of the window."""
        hwnd = ctypes.windll.user32.GetActiveWindow()
        if hwnd:
            GWL_STYLE = -16
            WS_MAXIMIZEBOX = 0x00010000
            WS_SIZEBOX = 0x00040000
            style = ctypes.windll.user32.GetWindowLongPtrW(hwnd, GWL_STYLE)
            style &= ~WS_MAXIMIZEBOX  # Disable maximize button
            style &= ~WS_SIZEBOX  # Disable resizing through borders
            ctypes.windll.user32.SetWindowLongPtrW(hwnd, GWL_STYLE, style)

    def start_check_for_updates(self):
        threading.Thread(target=self.check_for_updates).start()

    def check_for_updates(self):
        # Panggil fungsi selfupdate untuk memeriksa dan mengemas kini aplikasi
        selfupdate.get_latest_version_from_repo()

    def start_injection(self):
        threading.Thread(target=self.injection).start()

    def injection(self):
        # Cari proses GTA5 dan inject DLL
        self.show_loading_animation("Injecting LynnnMenu...")

        pID = injector.find_process_id("GTA5.exe")
        if pID:
            dll_path = os.path.join(os.getenv("APPDATA"), "Lynnn", "LynnnMenu.dll")
            try:
                injector.inject_dll(pID, dll_path)
                self.show_popup("LynnnMenu injected!")
            except Exception as e:
                self.show_popup(f"Injection failed: {e}")
        else:
            self.show_popup("I cant find GTA5 process!")

        # Tutup animasi loading
        self.hide_loading_animation()

    def show_loading_animation(self, message):
        """Buka progress bar loading dalam window baharu."""
        if self.progress_window is not None:
            return  # Jika window sudah ada, elak buka dua kali

        self.progress_window = ctk.CTkToplevel(self)
        self.progress_window.title("Loading...")
        self.progress_window.geometry("300x150")
        self.progress_window.resizable(False, False)

        label = ctk.CTkLabel(
            self.progress_window, text=message, font=("Helvetica", 14)
        )
        label.pack(pady=10)

        # Tambah progress bar
        self.progress_bar = ttk.Progressbar(
            self.progress_window, mode="indeterminate"
        )
        self.progress_bar.pack(pady=20, padx=20, fill="x")
        self.progress_bar.start(10)  # Start progress bar animation

    def hide_loading_animation(self):
        """Tutup progress bar loading."""
        if self.progress_window is not None:
            self.progress_window.destroy()
            self.progress_window = None

    def show_popup(self, message):
        """Tunjukkan popup ringkas dengan mesej yang dirapikan."""
        popup = ctk.CTkToplevel(self)
        popup.title("Update Status")
        popup.geometry("300x150")
        popup.resizable(False, False)

        # Label dengan padding dan penyesuaian
        label = ctk.CTkLabel(
            popup,
            text=message,
            font=("Helvetica", 14),
            justify="center",  # Pusatkan teks
            wraplength=280,  # Bungkus teks supaya tidak keluar dari kotak
        )
        label.pack(pady=(20, 10), padx=10)  # Tambah padding atas dan bawah

        # Butang tutup dengan jarak dari teks
        close_button = ctk.CTkButton(popup, text="Close", command=popup.destroy)
        close_button.pack(pady=(10, 20))  # Jarak atas kecil, bawah besar

    def open_discord(self):
        """Fungsi untuk membuka Discord server."""
        import webbrowser
        webbrowser.open("https://discord.gg/y2eaCzykZE")  # Gantikan dengan link Discord server sebenar


if __name__ == "__main__":
    app = LynnnMenuLaunchpad()
    app.mainloop()
