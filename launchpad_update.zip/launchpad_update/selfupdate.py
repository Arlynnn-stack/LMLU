import requests
import zipfile
import os
from io import BytesIO

def get_latest_version_from_repo():
    """Memeriksa versi terkini dari repo GitHub dan kemas kini aplikasi jika perlu."""
    # URL repositori GitHub untuk fail ZIP yang mengandungi kemas kini
    zip_url = "https://github.com/username/repository/raw/main/launchpad_update.zip"  # Gantikan dengan URL fail ZIP anda
    version_url = "https://github.com/Arlynnn-stack/LMLU/blob/main/version.txt"  # URL untuk fail version.txt

    # Muat turun versi terkini dari repositori
    response = requests.get(version_url)
    remote_version = response.text.strip()

    # Semak jika versi semasa lebih lama dari versi yang ada di repo
    if remote_version != get_current_version():
        print("A new update is available!")
        download_and_update(zip_url)
    else:
        print("You are using the latest version.")

def get_current_version():
    """Mengambil versi semasa dari fail version.txt dalam aplikasi."""
    try:
        with open("version.txt", "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "0.0"  # Jika fail version.txt tidak wujud, anggap versi 0.0

def download_and_update(zip_url):
    """Muat turun fail ZIP dan kemas kini aplikasi."""
    print("Downloading the latest update...")
    response = requests.get(zip_url)
    
    if response.status_code == 200:
        print("Update downloaded successfully. Extracting files...")
        
        # Ekstrak fail ZIP ke dalam direktori semasa
        with zipfile.ZipFile(BytesIO(response.content)) as zip_ref:
            zip_ref.extractall("./")  # Ekstrak fail ke dalam direktori semasa aplikasi
        print("Update completed successfully!")
    else:
        print("Failed to download the update. Please check your internet connection or the update URL.")

if __name__ == "__main__":
    get_latest_version_from_repo()
