import requests
import zipfile
import os
from io import BytesIO
import tkinter as tk
from tkinter import messagebox

def get_latest_version_from_repo():
    """Memeriksa versi terkini dari repo GitHub dan kemas kini aplikasi jika perlu."""
    zip_url = "https://raw.githubusercontent.com/Arlynnn-stack/LMLU/main/launchpad_update.zip"  # URL fail ZIP
    version_url = "https://raw.githubusercontent.com/Arlynnn-stack/LMLU/main/version.txt"  # URL untuk fail version.txt

    # Muat turun versi terkini dari repositori
    response = requests.get(version_url)
    remote_version = response.text.strip()

    # Semak jika versi semasa lebih lama dari versi yang ada di repo
    if remote_version != get_current_version():
        show_popup("Update Available", "Lynnn has been pushed new version!")
        download_and_update(zip_url)
    else:
        show_popup("No Update", "You are using the latest version.")

def get_current_version():
    """Mengambil versi semasa dari fail version.txt dalam aplikasi."""
    try:
        with open("version.txt", "r") as f:
            return f.read().strip()
    except FileNotFoundError:
        return "0.0"  # Jika fail version.txt tidak wujud, anggap versi 0.0

def download_and_update(zip_url):
    """Muat turun fail ZIP dan kemas kini aplikasi."""
    show_popup("Downloading Update", "Downloading the latest update...")
    response = requests.get(zip_url)

    if response.status_code == 200:
        show_popup("Extraction", "Update downloaded successfully. Extracting files...")
        
        # Ekstrak fail ZIP ke dalam direktori semasa
        with zipfile.ZipFile(BytesIO(response.content)) as zip_ref:
            zip_ref.extractall("./")  # Ekstrak fail ke dalam direktori semasa aplikasi
        show_popup("Update Completed", "Update completed successfully!\nPlease restart the application :)")
    else:
        show_popup("Download Failed", "Failed to download the update. Please check your internet connection or the update URL.")

def show_popup(title, message):
    """Menunjukkan popup dengan mesej tertentu."""
    root = tk.Tk()
    root.withdraw()  # Menyembunyikan tetingkap utama Tkinter
    messagebox.showinfo(title, message)

if __name__ == "__main__":
    get_latest_version_from_repo()
